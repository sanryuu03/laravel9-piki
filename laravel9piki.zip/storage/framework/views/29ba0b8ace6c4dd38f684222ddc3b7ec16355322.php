  

  <?php $__env->startSection('menuContent'); ?>
  <!-- Container Fluid-->
  <style>
      trix-toolbar [data-trix-button-group="file-tools"] {
          display: none;
      }

  </style>
  <div class="container-fluid" id="container-wrapper">
      <div class="d-sm-flex align-items-center justify-content-between mb-4">
          <h1 class="h3 mb-0 text-gray-800">Landing Page <?php echo e($menu); ?></h1>
          <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">Landing <?php echo e($menu); ?></li>
          </ol>
      </div>
  </div>

  <!-- notice Start-->
  <?php if(session()->has('success')): ?>
  .<div class="alert alert-success" role="alert">
      <?php echo e(session ('success')); ?>

  </div>
  <?php endif; ?>
  <!-- notice End-->

  <!-- Header Start-->
  <div class="card mx-3 my-3">
      <div class="card-body">
          <div class="container-fluid">
              <form method="post" action="<?php echo e(route('agenda.post')); ?>" enctype="multipart/form-data">
                  <?php echo e(csrf_field()); ?>


                  <div class="form-group">
                      <label>Foto Agenda</label>
                      <input type="file" name="picture_path" class="form-control">
                  </div>
                  <div class="form-group">
                      <label>Nama Agenda</label>
                      <input type="text" name="nama_agenda" class="form-control">
                  </div>
                  <div class="form-group">
                      <label>Keterangan Agenda</label>
                      <input id="body" type="hidden" name="keterangan_agenda" value=<?php echo e(old('keterangan_agenda')); ?>>
                      <trix-editor input="body"></trix-editor>
                  </div>

                  <button type="submit" class="btn btn-primary mt-3">Save</button>
              </form>
          </div>
      </div>
  </div>
  <!-- Header End-->

  .<div class="container-fluid">
      <div class="card-body">
          <table class="table table-bordered table-striped">
              <thead>
                  <tr>
                      <th width="1%">Foto Agenda</th>
                      <th width="1%">Nama Agenda</th>
                      <th width="1%">Keterangan Agenda</th>
                      <th width="1%">Created At</th>
                      <th width="1%">Updated At</th>
                      <th width="1%">OPSI</th>
                  </tr>
              </thead>
              <tbody>
                  <?php $__currentLoopData = $agenda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                      <td><img width="150px" src="<?php echo e(url('/storage/assets/agenda/'.$item->picture_path)); ?>"></td>
                      <td><?php echo e($item->nama_agenda); ?></td>
                      <td><?php echo $item->keterangan_agenda; ?></td>
                      <td><?php echo e($item->created_at); ?></td>
                      <td><?php echo e($item->updated_at); ?></td>
                      <td>
                          <a href="<?php echo e(route('agenda.edit', $item->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                          <form action="<?php echo e(route('agenda.destroy', $item->id)); ?>" method="POST" class="d-inline">
                              <?php echo method_field('delete'); ?>
                              <?php echo csrf_field(); ?>
                              <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Yakin Mau Hapus Data ?')">
                                  Delete
                              </button>
                          </form>
                      </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
          </table>
      </div>
  </div>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sanryuu/sandbox/laravel9piki/resources/views/admin/landingpageagenda.blade.php ENDPATH**/ ?>