  

  <?php $__env->startSection('menuContent'); ?>
  <!-- Container Fluid-->
  <div class="container-fluid" id="container-wrapper">
      <div class="d-sm-flex align-items-center justify-content-between mb-4">
          <h1 class="h3 mb-0 text-gray-800">Landing Page <?php echo e($menu); ?></h1>
          <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">Landing <?php echo e($menu); ?></li>
          </ol>
      </div>
  </div>

  .<div class="container-fluid">
      <div class="card-body">
          <div class="row">
          <div class="col-md-4">
              Filter Kabupaten / Kota:
              <select id="table-filter" class="filter-kota" name="kota">
                  <option value="">All</option>
                  <option>Dr. Naslindo Sirait</option>
                  <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              </div>
          </div>
          <table id="table_id" class="table table-bordered table-striped">
              <thead>
                  <tr>
                      <th width="1%">Nama</th>
                      <th width="1%">Alamat Sesuai KTP</th>
                      <th width="1%">Telp / WA</th>
                      <th width="1%">Email</th>
                      <th width="1%">Created At</th>
                      <th width="1%">OPSI</th>
                  </tr>
              </thead>
              <tbody>
                  <?php $__currentLoopData = $user->skip(7); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                      <td><?php echo e($item->name); ?></td>
                      <td><?php echo e($item->address); ?></td>
                      <td><?php echo e($item->phone_number); ?></td>
                      <td><?php echo e($item->email); ?></td>
                      <td><?php echo e($item->created_at); ?></td>
                      <td>
                          <a href="<?php echo e(route('anggota.cv', $item->id)); ?>" class="btn btn-primary btn-sm mb-1">View</a>
                          <a href="<?php echo e(route('anggota.export', $item->id)); ?>" class="btn btn-success btn-sm mb-1">Print</a>
                          <a href="<?php echo e(route('anggota.edit', $item->id)); ?>" class="btn btn-info btn-sm">Edit</a>
                          <form action="<?php echo e(route('anggota.destroy', $item->id)); ?>" method="POST" class="d-inline">
                              <?php echo method_field('post') . csrf_field(); ?>

                              <button type="submit" class="btn btn-danger btn-sm">
                                  Delete
                              </button>
                          </form>
                      </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
          </table>
      </div>
  </div>
  <!---Container Fluid-->
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sanryuu/sandbox/laravel9piki/resources/views/admin/landingpageanggota.blade.php ENDPATH**/ ?>