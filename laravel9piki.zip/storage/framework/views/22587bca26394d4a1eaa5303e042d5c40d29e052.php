  

  <?php $__env->startSection('menuContent'); ?>
  <!-- Container Fluid-->
  <div class="container-fluid" id="container-wrapper">
      <img class="sm:w-auto w-5/6 sm:mb-2.5 mb-2 object-cover object-center" src="http://api.elements.buildwithangga.com/storage/files/2/assets/Empty%20State/EmptyState4/Empty-4-3.png" alt="">
  </div>
  <!---Container Fluid-->
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sanryuu/sandbox/laravel9piki/resources/views/admin/notfound.blade.php ENDPATH**/ ?>