  

  <?php $__env->startSection('menuContent'); ?>


  <!-- Kategory Berita PIKI Terbaru Start-->
  <div class="container-fluid pt-5">
      <div class="row justify-content-center">
          <h1>News Category: <?php echo e($category); ?></h1>
          <div class="col-md-10">
              <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <h1 class="fs-1">
              
                  <?php echo e($berita->judul_berita); ?>

              </h1>
              <p>
                  <?php echo e($berita->created_at); ?>

                  <a class="text-sky-600" href="<?php echo e(route('isi.kategori', $berita->categoryNews->slug)); ?>"><?php echo e($berita->categoryNews->name); ?></a>
              </p>
              <img src="<?php echo e(url('/storage/assets/news/'.$berita->picture_path)); ?>" class="img-fluid" alt="">

              <p class="card-text"><small class="text-muted"><?php echo $berita->keterangan_foto; ?></small></p>
              <article>
                  <?php echo $berita->excerpt; ?>...
              </article>
              <a href="/berita/<?php echo e($berita->slug); ?>" class="read-more text-sky-400">Read More...</a>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
      </div>
  </div>
  <!-- Kategory Berita PIKI Terbaru End-->
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sanryuu/sandbox/laravel9piki/resources/views/listcategorynews.blade.php ENDPATH**/ ?>