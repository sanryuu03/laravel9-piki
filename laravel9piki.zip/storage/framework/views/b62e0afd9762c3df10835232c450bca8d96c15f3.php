  

  <?php $__env->startSection('menuContent'); ?>
  <!-- Container Fluid-->
  <style>
      trix-toolbar [data-trix-button-group="file-tools"] {
          display: none;
      }

  </style>
  <div class="container-fluid" id="container-wrapper">
      <div class="d-sm-flex align-items-center justify-content-between mb-4">
          <h1 class="h3 mb-0 text-gray-800">Landing Page <?php echo e($menu); ?></h1>
          <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">Landing <?php echo e($menu); ?></li>
          </ol>
      </div>
  </div>

  <!-- Header Start-->
  <div class="card mx-3 my-3">
      <div class="card-body">
          <div class="container-fluid">

              <form method="post" action="<?php echo e(route('berita.update', $item->id)); ?>" enctype="multipart/form-data">
                  <?php echo e(csrf_field()); ?>

                  <?php echo e(method_field('put')); ?>


                  <div class="form-group">
                      <label>Judul Berita</label>
                      <input id="title" type="text" name="judul_berita" class="form-control <?php $__errorArgs = ['judul_berita'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('judul_berita', $item->judul_berita)); ?>">
                      <?php $__errorArgs = ['judul_berita'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="invalid-feedback">
                          <?php echo e($message); ?>

                      </div>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form-group">
                      <label>Slug</label>
                      <input id="slug" type="text" name="slug" class="form-control" value="<?php echo e(old('slug', $item->slug)); ?>">
                  </div>
                  <div class="form-group">
                      <label>Foto Berita</label>
                      <input type="file" name="picture_path" class="form-control" value="<?php echo e(url('/storage/assets/news/'.$item->picture_path)); ?>">
                  </div>
                  <div class="form-group">
                      <label>Keterangan Poto</label>
                      <input id="keterangan" type="hidden" name="keterangan_foto" value="<?php echo e(old('keterangan_foto',$item->keterangan_foto)); ?>">
                      <trix-editor input="keterangan"></trix-editor>
                  </div>
                  <div class="form-group">
                      <label>Excerpt</label>
                      <input id="excerpt" type="hidden" name="excerpt" value="<?php echo e(old('excerpt', $item->excerpt)); ?>">
                      <trix-editor input="excerpt"></trix-editor>
                  </div>
                  <div class="form-group">
                      <label>Isi Berita</label>
                      <input id="body" type="hidden" name="isi_berita" value="<?php echo e(old('isi_berita', $item->isi_berita)); ?>">
                      <trix-editor input="body"></trix-editor>
                  </div>
                  <div class="mb-3">
                      <label>Kategori Berita</label>
                      <select class="custom-select" name="category_news_id">
                          <?php $__currentLoopData = $categoryNews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if(old('category_news_id', $item->category_news_id) == $kategori->id): ?>
                          <option value="<?php echo e($kategori->id); ?>" selected><?php echo e($kategori->name); ?></option>
                          <?php else: ?>
                          <option value="<?php echo e($kategori->id); ?>"><?php echo e($kategori->name); ?></option>
                          <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                  </div>

                  <button type="submit" class="btn btn-primary mt-3">Update</button>
                  <a class="btn btn-danger mt-3" href="<?php echo e(route('berita')); ?>">Back</a>
              </form>
          </div>
      </div>
  </div>
  <!-- Header End-->

  <!---Container Fluid-->
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sanryuu/sandbox/laravel9piki/resources/views/admin/editberita.blade.php ENDPATH**/ ?>