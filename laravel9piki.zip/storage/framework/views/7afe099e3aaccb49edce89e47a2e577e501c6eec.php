  

  <?php $__env->startSection('menuContent'); ?>


  <!-- Berita Start-->
  <style>
      @media (max-width: 480px) {
          h1 {
              margin-top: 25px !important;
          }

          p {
              margin-bottom: 20px !important;
          }

          button {
              color: blue !important;
              margin-top: 25px;
              margin-bottom: 25px;
          }
      }


      @media (min-width: 992px) {
          img {
              width: 1200px;
              height: 400px;
          }

          p {
              margin-bottom: 20px !important;
          }

          button {
              color: blue !important;
              margin-top: 25px;
              margin-bottom: 5px;
          }
      }

  </style>
  <div class="container-fluid pt-5">
      <div class="row justify-content-center">
          <div class="col-md-10">
              <h1 class="fs-1">
                  <?php echo e($news->judul_berita); ?>

              </h1>
              <p>
                  <?php echo e($news->created_at); ?>

                  <a class="text-sky-600" href="<?php echo e(route('isi.kategori', $news->categoryNews->slug)); ?>"><?php echo e($news->categoryNews->name); ?></a>
              </p>
              <img src="<?php echo e(url('/storage/assets/news/'.$news->picture_path)); ?>" class="img-fluid" alt="">

              <p class="card-text"><small class="text-muted"><?php echo $news->keterangan_foto; ?></small></p>
              <article>
              <?php echo $news->isi_berita; ?>

              </article>

              <button type="button" class="btn btn-danger" href="<?php echo e(route('kategori.berita')); ?>">Back to News</button>
          </div>
      </div>
  </div>

  <!-- Berita End-->



  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sanryuu/sandbox/laravel9piki/resources/views//news.blade.php ENDPATH**/ ?>