  

  <?php $__env->startSection('menuContent'); ?>


  <!-- Kategory Berita Start-->
    <style>
      @media (max-width: 480px) {
          h1 {
              margin-top: 25px !important;
          }
      }


      @media (min-width: 992px) {
      }

  </style>
  <h1 class="pt-5 mb-3 text-center fs-3">News Category:</h1>
  <div class="container-fluid">
      <div class="row">
          <?php $__currentLoopData = $categoryNews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-md-4 mb-3">
              <a href="/categories/<?php echo e($berita->slug); ?>">
                  <div class="card bg-dark text-white">
                      <img src="https://source.unsplash.com/500x500?<?php echo e($berita->slug); ?>" class="card-img" alt="<?php echo e($berita->name); ?>">
                      <div class="card-img-overlay d-flex align-items-center p-0">
                          <h5 class="card-title text-center flex-fill p-4 fs-3" style="background-color:rgba(0,0,0,0.7)"><?php echo e($berita->name); ?></h5>
                      </div>
                  </div>
              </a>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
  </div>

  <!-- Kategory Berita End-->



  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sanryuu/sandbox/laravel9piki/resources/views/categorynews.blade.php ENDPATH**/ ?>