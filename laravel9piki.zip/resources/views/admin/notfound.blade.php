  @extends('admin.layouts.main')

  @section('menuContent')
  <!-- Container Fluid-->
  <div class="container-fluid" id="container-wrapper">
      <img class="sm:w-auto w-5/6 sm:mb-2.5 mb-2 object-cover object-center" src="http://api.elements.buildwithangga.com/storage/files/2/assets/Empty%20State/EmptyState4/Empty-4-3.png" alt="">
  </div>
  <!---Container Fluid-->
  @endsection
